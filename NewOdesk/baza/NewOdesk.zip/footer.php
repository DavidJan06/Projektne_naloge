</div>
<div id="">
    <div id="">
        Copyright © 2048 <a href="#">Company Name</a> - Designed by <a href="#">Company</a>
        <div class=""></div>
    </div>
</div>  
        
</body>
</html>